import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertRepairAppointmentSchema, insertSellRequestSchema, insertOrderSchema, insertProductSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { isAuthenticated, authStorage } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProductById(parseInt(req.params.id));
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: fromZodError(error).toString() 
        });
      }
      console.error("Error creating product:", error);
      res.status(500).json({ error: "Failed to create product" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.updateProduct(parseInt(req.params.id), req.body);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteProduct(parseInt(req.params.id));
      if (!deleted) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  app.post("/api/repair-appointments", async (req, res) => {
    try {
      const validatedData = insertRepairAppointmentSchema.parse(req.body);
      const appointment = await storage.createRepairAppointment(validatedData);
      res.status(201).json(appointment);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: fromZodError(error).toString() 
        });
      }
      console.error("Error creating repair appointment:", error);
      res.status(500).json({ error: "Failed to create repair appointment" });
    }
  });

  app.get("/api/repair-appointments", async (req, res) => {
    try {
      const appointments = await storage.getRepairAppointments();
      res.json(appointments);
    } catch (error) {
      console.error("Error fetching repair appointments:", error);
      res.status(500).json({ error: "Failed to fetch repair appointments" });
    }
  });

  app.get("/api/repair-appointments/:id", async (req, res) => {
    try {
      const appointment = await storage.getRepairAppointmentById(req.params.id);
      if (!appointment) {
        return res.status(404).json({ error: "Appointment not found" });
      }
      res.json(appointment);
    } catch (error) {
      console.error("Error fetching repair appointment:", error);
      res.status(500).json({ error: "Failed to fetch repair appointment" });
    }
  });

  app.post("/api/sell-requests", async (req, res) => {
    try {
      const validatedData = insertSellRequestSchema.parse(req.body);
      
      if (!validatedData.images || validatedData.images.length === 0) {
        return res.status(400).json({ error: "At least one image is required" });
      }
      
      const request = await storage.createSellRequest(validatedData);
      res.status(201).json(request);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: fromZodError(error).toString() 
        });
      }
      console.error("Error creating sell request:", error);
      res.status(500).json({ error: "Failed to create sell request" });
    }
  });

  app.get("/api/sell-requests", async (req, res) => {
    try {
      const requests = await storage.getSellRequests();
      res.json(requests);
    } catch (error) {
      console.error("Error fetching sell requests:", error);
      res.status(500).json({ error: "Failed to fetch sell requests" });
    }
  });

  app.get("/api/sell-requests/:id", async (req, res) => {
    try {
      const request = await storage.getSellRequestById(req.params.id);
      if (!request) {
        return res.status(404).json({ error: "Sell request not found" });
      }
      res.json(request);
    } catch (error) {
      console.error("Error fetching sell request:", error);
      res.status(500).json({ error: "Failed to fetch sell request" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const validatedData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(validatedData);
      res.status(201).json(order);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: fromZodError(error).toString() 
        });
      }
      console.error("Error creating order:", error);
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  app.get("/api/orders", async (req, res) => {
    try {
      const orders = await storage.getOrders();
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", async (req, res) => {
    try {
      const order = await storage.getOrderById(req.params.id);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      console.error("Error fetching order:", error);
      res.status(500).json({ error: "Failed to fetch order" });
    }
  });

  app.get("/api/my/orders", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      if (!userId) {
        return res.status(400).json({ error: "User ID not found" });
      }
      const user = await authStorage.getUser(userId);
      if (!user?.email) {
        return res.json([]);
      }
      const orders = await storage.getOrdersByEmail(user.email);
      res.json(orders);
    } catch (error) {
      console.error("Error fetching user orders:", error);
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.get("/api/my/repair-appointments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      if (!userId) {
        return res.status(400).json({ error: "User ID not found" });
      }
      const user = await authStorage.getUser(userId);
      if (!user?.email) {
        return res.json([]);
      }
      const appointments = await storage.getRepairAppointmentsByEmail(user.email);
      res.json(appointments);
    } catch (error) {
      console.error("Error fetching user repair appointments:", error);
      res.status(500).json({ error: "Failed to fetch repair appointments" });
    }
  });

  app.get("/api/my/sell-requests", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      if (!userId) {
        return res.status(400).json({ error: "User ID not found" });
      }
      const user = await authStorage.getUser(userId);
      if (!user?.email) {
        return res.json([]);
      }
      const requests = await storage.getSellRequestsByEmail(user.email);
      res.json(requests);
    } catch (error) {
      console.error("Error fetching user sell requests:", error);
      res.status(500).json({ error: "Failed to fetch sell requests" });
    }
  });

  return httpServer;
}
