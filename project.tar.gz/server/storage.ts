import { db } from "./db";
import { 
  repairAppointments, 
  sellRequests,
  orders,
  products,
  type RepairAppointment,
  type InsertRepairAppointment,
  type SellRequest,
  type InsertSellRequest,
  type Order,
  type InsertOrder,
  type Product,
  type InsertProduct
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  createRepairAppointment(appointment: InsertRepairAppointment): Promise<RepairAppointment>;
  getRepairAppointments(): Promise<RepairAppointment[]>;
  getRepairAppointmentById(id: string): Promise<RepairAppointment | undefined>;
  getRepairAppointmentsByEmail(email: string): Promise<RepairAppointment[]>;
  
  createSellRequest(request: InsertSellRequest): Promise<SellRequest>;
  getSellRequests(): Promise<SellRequest[]>;
  getSellRequestById(id: string): Promise<SellRequest | undefined>;
  getSellRequestsByEmail(email: string): Promise<SellRequest[]>;
  
  createOrder(order: InsertOrder): Promise<Order>;
  getOrders(): Promise<Order[]>;
  getOrderById(id: string): Promise<Order | undefined>;
  getOrdersByEmail(email: string): Promise<Order[]>;
}

export class DatabaseStorage implements IStorage {
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProductById(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [created] = await db.insert(products).values(product).returning();
    return created;
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const [updated] = await db.update(products).set(product).where(eq(products.id, id)).returning();
    return updated;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id)).returning();
    return result.length > 0;
  }

  async createRepairAppointment(appointment: InsertRepairAppointment): Promise<RepairAppointment> {
    const [created] = await db.insert(repairAppointments).values(appointment).returning();
    return created;
  }

  async getRepairAppointments(): Promise<RepairAppointment[]> {
    return await db.select().from(repairAppointments).orderBy(desc(repairAppointments.createdAt));
  }

  async getRepairAppointmentById(id: string): Promise<RepairAppointment | undefined> {
    const [appointment] = await db.select().from(repairAppointments).where(eq(repairAppointments.id, id));
    return appointment;
  }

  async getRepairAppointmentsByEmail(email: string): Promise<RepairAppointment[]> {
    return await db.select().from(repairAppointments).where(eq(repairAppointments.email, email)).orderBy(desc(repairAppointments.createdAt));
  }

  async createSellRequest(request: InsertSellRequest): Promise<SellRequest> {
    const [created] = await db.insert(sellRequests).values(request).returning();
    return created;
  }

  async getSellRequests(): Promise<SellRequest[]> {
    return await db.select().from(sellRequests).orderBy(desc(sellRequests.createdAt));
  }

  async getSellRequestById(id: string): Promise<SellRequest | undefined> {
    const [request] = await db.select().from(sellRequests).where(eq(sellRequests.id, id));
    return request;
  }

  async getSellRequestsByEmail(email: string): Promise<SellRequest[]> {
    return await db.select().from(sellRequests).where(eq(sellRequests.email, email)).orderBy(desc(sellRequests.createdAt));
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const [created] = await db.insert(orders).values(order).returning();
    return created;
  }

  async getOrders(): Promise<Order[]> {
    return await db.select().from(orders).orderBy(desc(orders.createdAt));
  }

  async getOrderById(id: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  }

  async getOrdersByEmail(email: string): Promise<Order[]> {
    return await db.select().from(orders).where(eq(orders.customerEmail, email)).orderBy(desc(orders.createdAt));
  }
}

export const storage = new DatabaseStorage();
