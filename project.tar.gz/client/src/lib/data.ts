import heroImage from "@assets/generated_images/futuristic_tech_store_hero_background.png";
import gamingLaptop from "@assets/generated_images/gaming_laptop_product_shot.png";
import ultrabook from "@assets/generated_images/ultrabook_product_shot.png";
import repairImage from "@assets/generated_images/laptop_repair_service.png";

export const products = [
  {
    id: 1,
    name: "Titan GT77 HX",
    brand: "MSI",
    price: 4299.99,
    category: "Gaming",
    image: gamingLaptop,
    condition: "New",
    specs: {
      cpu: "i9-13980HX",
      gpu: "RTX 4090",
      ram: "64GB DDR5",
      storage: "2TB NVMe SSD",
      os: "Windows 11 Pro",
      screen: "17.3\" 4K Mini-LED"
    },
    inStock: true
  },
  {
    id: 2,
    name: "Blade 16",
    brand: "Razer",
    price: 3599.99,
    category: "Gaming",
    image: gamingLaptop,
    condition: "New",
    specs: {
      cpu: "i9-13950HX",
      gpu: "RTX 4080",
      ram: "32GB DDR5",
      storage: "1TB NVMe SSD",
      os: "Windows 11 Home",
      screen: "16\" QHD+ 240Hz"
    },
    inStock: true
  },
  {
    id: 3,
    name: "XPS 15",
    brand: "Dell",
    price: 2199.99,
    category: "Workstation",
    image: ultrabook,
    condition: "Refurbished",
    specs: {
      cpu: "i7-13700H",
      gpu: "RTX 4050",
      ram: "32GB DDR5",
      storage: "512GB NVMe SSD",
      os: "Windows 11 Pro",
      screen: "15.6\" OLED Touch"
    },
    inStock: true
  },
  {
    id: 4,
    name: "MacBook Pro 16",
    brand: "Apple",
    price: 2499.00,
    category: "Creative",
    image: ultrabook,
    condition: "New",
    specs: {
      cpu: "M3 Max",
      gpu: "30-core GPU",
      ram: "36GB Unified",
      storage: "1TB SSD",
      os: "macOS Sonoma",
      screen: "16.2\" Liquid Retina"
    },
    inStock: true
  },
  {
    id: 5,
    name: "ROG Zephyrus G14",
    brand: "ASUS",
    price: 1849.99,
    category: "Gaming",
    image: gamingLaptop,
    condition: "Used",
    specs: {
      cpu: "Ryzen 9 7940HS",
      gpu: "RTX 4070",
      ram: "16GB DDR5",
      storage: "512GB NVMe SSD",
      os: "Windows 11 Home",
      screen: "14\" QHD+ 165Hz"
    },
    inStock: false
  },
  {
    id: 6,
    name: "ThinkPad X1 Carbon",
    brand: "Lenovo",
    price: 1999.00,
    category: "Business",
    image: ultrabook,
    condition: "Refurbished",
    specs: {
      cpu: "i7-1365U",
      gpu: "Iris Xe",
      ram: "32GB LPDDR5",
      storage: "1TB NVMe SSD",
      os: "Windows 11 Pro",
      screen: "14\" WUXGA"
    },
    inStock: true
  }
];

export const services = [
  {
    id: "repair",
    title: "Expert Repair",
    description: "Hardware fixes, screen replacements, and liquid damage recovery by certified pros.",
    image: repairImage,
    price: "From $49"
  },
  {
    id: "consult",
    title: "Tech Consultation",
    description: "Not sure what you need? Book a 1-on-1 with our experts to find your perfect rig.",
    image: heroImage, // Using hero as fallback
    price: "Free"
  },
  {
    id: "sell",
    title: "Sell Your Device",
    description: "Get a fair quote for your old laptop instantly. Cash or store credit available.",
    image: ultrabook,
    price: "Get Quote"
  }
];
