import { ArrowRight, Phone, Mail, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { useState, type MouseEvent } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface ServiceCardProps {
  title: string;
  description: string;
  image: string;
  price: string;
  link: string;
  isConsultation?: boolean;
}

const contactInfo = {
  phone: "+1 (555) 123-4567",
  email: "consult@techstorepro.com",
  whatsapp: "+1 (555) 987-6543",
};

export function ServiceCard({ title, description, image, price, link, isConsultation = false }: ServiceCardProps) {
  const [dialogOpen, setDialogOpen] = useState(false);

  const handleBookNow = (e: MouseEvent<HTMLButtonElement>) => {
    if (isConsultation) {
      e.preventDefault();
      setDialogOpen(true);
    }
  };

  return (
    <>
      <Card className="group overflow-hidden border-border/50 bg-card hover:border-primary/50 transition-all duration-300">
        <div className="grid md:grid-cols-2 gap-0 h-full">
          <div className="relative h-48 md:h-full overflow-hidden">
            <div className="absolute inset-0 bg-primary/20 mix-blend-overlay z-10 group-hover:bg-transparent transition-colors" />
            <img 
              src={image} 
              alt={title} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          </div>
          <CardContent className="p-6 flex flex-col justify-center h-full">
            <div className="space-y-4">
              <div>
                <h3 className="font-display font-bold text-2xl mb-2">{title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {description}
                </p>
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-border/50">
                <span className="font-mono text-accent text-lg">{price}</span>
                {isConsultation ? (
                  <Button 
                    variant="outline" 
                    className="group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary transition-all"
                    onClick={handleBookNow}
                    data-testid="button-book-consultation"
                  >
                    Book Now <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                ) : (
                  <Link href={link}>
                    <Button variant="outline" className="group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary transition-all">
                      Book Now <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                )}
              </div>
            </div>
          </CardContent>
        </div>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-display">Book a Consultation</DialogTitle>
            <DialogDescription>
              Get in touch with our tech expert for a free 15-minute consultation.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <a 
              href={`tel:${contactInfo.phone.replace(/\D/g, '')}`}
              className="flex items-center gap-4 p-4 rounded-lg border border-border/50 bg-secondary/20 hover:bg-secondary/40 transition-colors cursor-pointer"
              data-testid="link-phone"
            >
              <div className="bg-primary/10 p-3 rounded-full">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">Phone</p>
                <p className="text-muted-foreground">{contactInfo.phone}</p>
              </div>
            </a>

            <a 
              href={`mailto:${contactInfo.email}`}
              className="flex items-center gap-4 p-4 rounded-lg border border-border/50 bg-secondary/20 hover:bg-secondary/40 transition-colors cursor-pointer"
              data-testid="link-email"
            >
              <div className="bg-primary/10 p-3 rounded-full">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">Email</p>
                <p className="text-muted-foreground">{contactInfo.email}</p>
              </div>
            </a>

            <a 
              href={`https://wa.me/${contactInfo.whatsapp.replace(/\D/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-4 rounded-lg border border-border/50 bg-secondary/20 hover:bg-secondary/40 transition-colors cursor-pointer"
              data-testid="link-whatsapp"
            >
              <div className="bg-green-500/10 p-3 rounded-full">
                <MessageCircle className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <p className="font-medium text-foreground">WhatsApp</p>
                <p className="text-muted-foreground">{contactInfo.whatsapp}</p>
              </div>
            </a>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
