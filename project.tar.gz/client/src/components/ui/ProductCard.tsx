import { motion } from "framer-motion";
import { ShoppingCart, Check, Cpu, CircuitBoard, HardDrive, Monitor, Database } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { useCart } from "@/lib/cart";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Link } from "wouter";

interface ProductSpecs {
  cpu: string;
  gpu: string;
  ram: string;
  storage: string;
  os: string;
  screen: string;
}

interface ProductCardProps {
  id: number;
  name: string;
  brand: string;
  price: number;
  image: string;
  condition: string;
  specs: ProductSpecs;
  inStock: boolean;
}

const conditionColors: Record<string, string> = {
  "New": "bg-green-500/20 text-green-400 border-green-500/30",
  "Refurbished": "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  "Used": "bg-orange-500/20 text-orange-400 border-orange-500/30",
};

export function ProductCard({ id, name, brand, price, image, condition, specs, inStock }: ProductCardProps) {
  const { addItem } = useCart();
  const { toast } = useToast();
  const [added, setAdded] = useState(false);

  const handleAddToCart = () => {
    addItem({ id, name, brand, price, image });
    setAdded(true);
    toast({
      title: "Added to Cart",
      description: `${name} has been added to your cart.`,
    });
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="group overflow-hidden border-border/50 bg-card/50 backdrop-blur-sm hover:border-primary/50 transition-all duration-300 h-full flex flex-col">
        <Link href={`/product/${id}`} data-testid={`link-product-${id}`}>
          <div className="relative aspect-square overflow-hidden bg-secondary/20 p-6 flex items-center justify-center cursor-pointer">
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <Badge 
              className={`absolute top-3 left-3 z-10 border ${conditionColors[condition] || conditionColors["New"]}`}
              data-testid={`badge-condition-${id}`}
            >
              {condition}
            </Badge>
            <img 
              src={image} 
              alt={name} 
              className="w-full h-full object-contain transform group-hover:scale-110 transition-transform duration-500 drop-shadow-2xl"
            />
            {!inStock && (
              <div className="absolute inset-0 bg-background/60 backdrop-blur-[2px] flex items-center justify-center">
                <Badge variant="destructive" className="text-lg px-4 py-2">Out of Stock</Badge>
              </div>
            )}
          </div>

          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-mono text-primary/80 uppercase tracking-wider mb-1">{brand}</p>
                <h3 className="font-display font-bold text-xl leading-tight text-foreground group-hover:text-primary transition-colors">
                  {name}
                </h3>
              </div>
              <div className="text-right">
                <span className="font-display font-bold text-lg text-accent">
                  ${price.toLocaleString()}
                </span>
              </div>
            </div>
          </CardHeader>
        </Link>

        <CardContent className="space-y-3 flex-grow">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-1.5 text-muted-foreground bg-secondary/30 p-1.5 rounded border border-border/30">
              <Cpu className="w-3.5 h-3.5 text-primary" />
              <span className="truncate">{specs.cpu}</span>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground bg-secondary/30 p-1.5 rounded border border-border/30">
              <CircuitBoard className="w-3.5 h-3.5 text-primary" />
              <span className="truncate">{specs.gpu}</span>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground bg-secondary/30 p-1.5 rounded border border-border/30">
              <HardDrive className="w-3.5 h-3.5 text-primary" />
              <span className="truncate">{specs.ram}</span>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground bg-secondary/30 p-1.5 rounded border border-border/30">
              <Database className="w-3.5 h-3.5 text-primary" />
              <span className="truncate">{specs.storage}</span>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground bg-secondary/30 p-1.5 rounded border border-border/30 col-span-2">
              <Monitor className="w-3.5 h-3.5 text-primary" />
              <span className="truncate">{specs.os}</span>
            </div>
          </div>
        </CardContent>

        <CardFooter className="pt-0">
          <Button 
            className="w-full font-medium" 
            variant={added ? "secondary" : inStock ? "default" : "secondary"}
            disabled={!inStock}
            onClick={handleAddToCart}
            data-testid={`button-add-cart-${id}`}
          >
            {added ? (
              <>
                <Check className="w-4 h-4 mr-2" />
                Added!
              </>
            ) : inStock ? (
              <>
                <ShoppingCart className="w-4 h-4 mr-2" />
                Add to Cart
              </>
            ) : (
              "Notify Me"
            )}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
