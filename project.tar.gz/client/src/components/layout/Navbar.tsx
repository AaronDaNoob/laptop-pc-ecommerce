import { Link, useLocation } from "wouter";
import { ShoppingCart, User, Search, Menu, Cpu, LogOut, LogIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Navbar() {
  const [location] = useLocation();
  const { totalItems } = useCart();
  const { user, isLoading, isAuthenticated } = useAuth();

  const isActive = (path: string) => location === path;

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    const first = firstName?.[0] || '';
    const last = lastName?.[0] || '';
    return (first + last).toUpperCase() || 'U';
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group" data-testid="link-home-logo">
          <div className="bg-primary/10 p-2 rounded-lg border border-primary/20 group-hover:border-primary/50 transition-colors">
            <Cpu className="h-6 w-6 text-primary" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight text-foreground">
            CLUB<span className="text-primary">LAPTOPS</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <Link href="/" className={`text-sm font-medium transition-colors hover:text-primary ${isActive('/') ? 'text-primary' : 'text-muted-foreground'}`} data-testid="link-nav-home">
            Home
          </Link>
          <Link href="/shop" className={`text-sm font-medium transition-colors hover:text-primary ${isActive('/shop') ? 'text-primary' : 'text-muted-foreground'}`} data-testid="link-nav-shop">
            Shop
          </Link>
          <Link href="/services" className={`text-sm font-medium transition-colors hover:text-primary ${isActive('/services') ? 'text-primary' : 'text-muted-foreground'}`} data-testid="link-nav-services">
            Services & Repair
          </Link>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden md:flex relative group">
             <Input 
              className="w-64 bg-secondary/50 border-transparent focus:border-primary/50 focus:bg-secondary transition-all rounded-full pl-10 h-9" 
              placeholder="Search specific specs..." 
              data-testid="input-search"
            />
            <Search className="h-4 w-4 absolute left-3 top-2.5 text-muted-foreground" />
          </div>

          {isLoading ? (
            <Button variant="ghost" size="icon" className="hover:text-primary" disabled>
              <User className="h-5 w-5 animate-pulse" />
            </Button>
          ) : isAuthenticated && user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="hover:text-primary relative" data-testid="button-user-menu">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || 'User'} />
                    <AvatarFallback className="bg-primary/10 text-primary text-xs">
                      {getInitials(user.firstName, user.lastName)}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-1.5">
                  <p className="text-sm font-medium">
                    {user.firstName || user.lastName 
                      ? `${user.firstName || ''} ${user.lastName || ''}`.trim() 
                      : 'User'}
                  </p>
                  {user.email && <p className="text-xs text-muted-foreground">{user.email}</p>}
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/account" className="cursor-pointer" data-testid="link-account">
                    <User className="mr-2 h-4 w-4" />
                    My Account
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <a href="/api/logout" className="cursor-pointer text-destructive" data-testid="button-logout">
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </a>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <a href="/api/login">
              <Button variant="ghost" size="icon" className="hover:text-primary" data-testid="button-login">
                <LogIn className="h-5 w-5" />
              </Button>
            </a>
          )}
          
          <Link href="/checkout">
            <Button variant="ghost" size="icon" className="relative hover:text-primary" data-testid="button-cart">
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-accent text-accent-foreground text-xs flex items-center justify-center font-bold">
                  {totalItems}
                </span>
              )}
            </Button>
          </Link>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" data-testid="button-mobile-menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] border-l-border/50 bg-background/95 backdrop-blur-xl">
              <div className="flex flex-col gap-8 mt-10">
                <Link href="/" className="text-lg font-medium hover:text-primary">Home</Link>
                <Link href="/shop" className="text-lg font-medium hover:text-primary">Shop Laptops</Link>
                <Link href="/services" className="text-lg font-medium hover:text-primary">Services & Repair</Link>
                <Link href="/checkout" className="text-lg font-medium hover:text-primary">Cart ({totalItems})</Link>
                <div className="h-px bg-border/50 my-2" />
                {isAuthenticated && user ? (
                  <>
                    <Link href="/account" className="text-lg font-medium hover:text-primary">
                      My Account
                    </Link>
                    <a href="/api/logout" className="text-lg font-medium text-destructive hover:text-destructive/80">
                      Logout
                    </a>
                  </>
                ) : (
                  <a href="/api/login">
                    <Button className="w-full justify-start" variant="outline">
                      <LogIn className="mr-2 h-4 w-4" /> Login / Sign Up
                    </Button>
                  </a>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
