import { Cpu, Facebook, Instagram, Twitter, Shield } from "lucide-react";
import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-secondary/20 border-t border-border/50 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="bg-primary/10 p-2 rounded-lg border border-primary/20">
                <Cpu className="h-6 w-6 text-primary" />
              </div>
              <span className="font-display font-bold text-xl tracking-tight text-foreground">
                CLUB<span className="text-primary">LAPTOPS</span>
              </span>
            </Link>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Premium high-performance computing solutions. Expert repairs, custom builds, and trade-ins for the modern enthusiast.
            </p>
          </div>
          
          <div>
            <h4 className="font-display font-bold text-lg mb-4">Shop</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/shop" className="hover:text-primary transition-colors">Gaming Laptops</Link></li>
              <li><Link href="/shop" className="hover:text-primary transition-colors">Workstations</Link></li>
              <li><Link href="/shop" className="hover:text-primary transition-colors">Ultrabooks</Link></li>
              <li><Link href="/shop" className="hover:text-primary transition-colors">Accessories</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-bold text-lg mb-4">Services</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/services" className="hover:text-primary transition-colors">Laptop Repair</Link></li>
              <li><Link href="/services" className="hover:text-primary transition-colors">Data Recovery</Link></li>
              <li><Link href="/services" className="hover:text-primary transition-colors">Sell Your Device</Link></li>
              <li><Link href="/services" className="hover:text-primary transition-colors">Consultation</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-bold text-lg mb-4">Store Info</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>123 Tech Avenue, Silicon District</li>
              <li>Daily: 10:00 AM - 9:00 PM</li>
              <li>support@clublaptops.com</li>
              <li>(555) 123-4567</li>
            </ul>
            <div className="flex gap-4 mt-6">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Facebook size={20} /></a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Twitter size={20} /></a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Instagram size={20} /></a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-border/30 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Club Laptops. All rights reserved.
          </div>
          <Link 
            href="/admin" 
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
            data-testid="link-admin-login"
          >
            <Shield className="h-4 w-4" />
            Login as Admin
          </Link>
        </div>
      </div>
    </footer>
  );
}
