import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { ShoppingBag, Wrench, DollarSign, User, LogOut, Package } from "lucide-react";
import { Link } from "wouter";
import type { Order, RepairAppointment, SellRequest } from "@shared/schema";

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
    pending: "secondary",
    confirmed: "default",
    completed: "outline",
    cancelled: "destructive",
  };
  
  return (
    <Badge variant={variants[status] || "secondary"} className="capitalize">
      {status}
    </Badge>
  );
}

export default function Account() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();

  const { data: orders, isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ["/api/my/orders"],
    queryFn: async () => {
      const res = await fetch("/api/my/orders");
      if (!res.ok) throw new Error("Failed to fetch orders");
      return res.json();
    },
    enabled: isAuthenticated,
  });

  const { data: repairs, isLoading: repairsLoading } = useQuery<RepairAppointment[]>({
    queryKey: ["/api/my/repair-appointments"],
    queryFn: async () => {
      const res = await fetch("/api/my/repair-appointments");
      if (!res.ok) throw new Error("Failed to fetch repairs");
      return res.json();
    },
    enabled: isAuthenticated,
  });

  const { data: sellRequests, isLoading: sellsLoading } = useQuery<SellRequest[]>({
    queryKey: ["/api/my/sell-requests"],
    queryFn: async () => {
      const res = await fetch("/api/my/sell-requests");
      if (!res.ok) throw new Error("Failed to fetch sell requests");
      return res.json();
    },
    enabled: isAuthenticated,
  });

  if (authLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="container mx-auto px-4 py-24">
        <div className="max-w-md mx-auto text-center">
          <User className="h-16 w-16 mx-auto text-muted-foreground mb-6" />
          <h1 className="text-2xl font-display font-bold mb-4">Please Log In</h1>
          <p className="text-muted-foreground mb-8">
            Log in to view your account, orders, and service requests.
          </p>
          <a href="/api/login">
            <Button size="lg" data-testid="button-login-account">
              Login / Sign Up
            </Button>
          </a>
        </div>
      </div>
    );
  }

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    const first = firstName?.[0] || '';
    const last = lastName?.[0] || '';
    return (first + last).toUpperCase() || 'U';
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto space-y-8">
        <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="flex items-center gap-6">
              <Avatar className="h-20 w-20">
                <AvatarImage src={user?.profileImageUrl || undefined} alt={user?.firstName || 'User'} />
                <AvatarFallback className="bg-primary/10 text-primary text-2xl">
                  {getInitials(user?.firstName, user?.lastName)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h1 className="text-2xl font-display font-bold" data-testid="text-user-name">
                  {user?.firstName || user?.lastName 
                    ? `${user?.firstName || ''} ${user?.lastName || ''}`.trim() 
                    : 'Welcome!'}
                </h1>
                {user?.email && (
                  <p className="text-muted-foreground" data-testid="text-user-email">{user.email}</p>
                )}
              </div>
              <a href="/api/logout">
                <Button variant="outline" className="gap-2" data-testid="button-logout-account">
                  <LogOut className="h-4 w-4" />
                  Logout
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="orders" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="orders" className="gap-2" data-testid="tab-orders">
              <ShoppingBag className="h-4 w-4" />
              Orders ({orders?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="repairs" className="gap-2" data-testid="tab-repairs">
              <Wrench className="h-4 w-4" />
              Repairs ({repairs?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="sell" className="gap-2" data-testid="tab-sell">
              <DollarSign className="h-4 w-4" />
              Sell Requests ({sellRequests?.length || 0})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="mt-6">
            <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="font-display">Your Orders</CardTitle>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-20 w-full" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                ) : orders && orders.length > 0 ? (
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <div 
                        key={order.id} 
                        className="p-4 rounded-lg border border-border/50 bg-secondary/20"
                        data-testid={`order-item-${order.id}`}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">Order #{order.id.slice(0, 8)}</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(order.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <StatusBadge status={order.status} />
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-sm text-muted-foreground">
                            {(order.items as any[]).length} item(s)
                          </p>
                          <p className="font-mono font-bold text-primary">
                            ${(order.totalAmount / 100).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground mb-4">No orders yet</p>
                    <Link href="/shop">
                      <Button data-testid="button-shop-now">Shop Now</Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="repairs" className="mt-6">
            <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="font-display">Repair Appointments</CardTitle>
              </CardHeader>
              <CardContent>
                {repairsLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-20 w-full" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                ) : repairs && repairs.length > 0 ? (
                  <div className="space-y-4">
                    {repairs.map((repair) => (
                      <div 
                        key={repair.id} 
                        className="p-4 rounded-lg border border-border/50 bg-secondary/20"
                        data-testid={`repair-item-${repair.id}`}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">{repair.deviceModel}</p>
                            <p className="text-sm text-muted-foreground">
                              Appointment: {new Date(repair.appointmentDate).toLocaleDateString()}
                            </p>
                          </div>
                          <StatusBadge status={repair.status} />
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-2">{repair.issue}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Wrench className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground mb-4">No repair appointments</p>
                    <Link href="/services">
                      <Button data-testid="button-book-repair">Book a Repair</Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sell" className="mt-6">
            <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="font-display">Sell Requests</CardTitle>
              </CardHeader>
              <CardContent>
                {sellsLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-20 w-full" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                ) : sellRequests && sellRequests.length > 0 ? (
                  <div className="space-y-4">
                    {sellRequests.map((request) => (
                      <div 
                        key={request.id} 
                        className="p-4 rounded-lg border border-border/50 bg-secondary/20"
                        data-testid={`sell-item-${request.id}`}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">{request.deviceModel}</p>
                            <p className="text-sm text-muted-foreground">
                              Submitted: {new Date(request.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <StatusBadge status={request.status} />
                        </div>
                        {request.estimatedValue && (
                          <p className="font-mono font-bold text-primary">
                            Estimated: ${request.estimatedValue}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <DollarSign className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground mb-4">No sell requests</p>
                    <Link href="/services">
                      <Button data-testid="button-sell-device">Sell Your Device</Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
