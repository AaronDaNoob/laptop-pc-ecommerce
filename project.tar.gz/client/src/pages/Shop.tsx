import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Filter, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ProductCard } from "@/components/ui/ProductCard";
import { products as staticProducts } from "@/lib/data";
import type { Product, ProductSpecs } from "@shared/schema";

const CATEGORIES = ["All", "Gaming", "Workstation", "Business", "Creative"];
const BRANDS = ["MSI", "Razer", "Dell", "Apple", "ASUS", "Lenovo"];

export default function Shop() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState([0, 5000]);

  const { data: dbProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: async () => {
      const res = await fetch("/api/products");
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const products = dbProducts && dbProducts.length > 0 
    ? dbProducts.map(p => ({
        id: p.id,
        name: p.name,
        brand: p.brand,
        price: p.price / 100,
        category: p.category,
        image: p.image,
        condition: p.condition,
        specs: p.specs as ProductSpecs,
        inStock: p.inStock,
      }))
    : staticProducts;

  const toggleBrand = (brand: string) => {
    setSelectedBrands(prev => 
      prev.includes(brand) 
        ? prev.filter(b => b !== brand)
        : [...prev, brand]
    );
  };

  const filteredProducts = products.filter(product => {
    const categoryMatch = selectedCategory === "All" || product.category === selectedCategory;
    const brandMatch = selectedBrands.length === 0 || selectedBrands.includes(product.brand);
    const priceMatch = product.price >= priceRange[0] && product.price <= priceRange[1];
    return categoryMatch && brandMatch && priceMatch;
  });

  const FilterContent = () => (
    <div className="space-y-8">
      <div>
        <h3 className="font-display font-bold text-lg mb-4">Categories</h3>
        <div className="space-y-2">
          {CATEGORIES.map(category => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="font-display font-bold text-lg mb-4">Price Range</h3>
        <div className="px-2">
          <Slider
            defaultValue={[0, 5000]}
            max={5000}
            step={100}
            value={priceRange}
            onValueChange={setPriceRange}
            className="mb-4"
          />
          <div className="flex justify-between text-sm font-mono text-muted-foreground">
            <span>${priceRange[0]}</span>
            <span>${priceRange[1]}</span>
          </div>
        </div>
      </div>

      <div>
        <h3 className="font-display font-bold text-lg mb-4">Brands</h3>
        <div className="space-y-3">
          {BRANDS.map(brand => (
            <div key={brand} className="flex items-center space-x-2">
              <Checkbox 
                id={brand} 
                checked={selectedBrands.includes(brand)}
                onCheckedChange={() => toggleBrand(brand)}
              />
              <Label htmlFor={brand} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                {brand}
              </Label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Mobile Filters */}
        <div className="md:hidden flex justify-between items-center mb-4">
          <h1 className="text-3xl font-display font-bold">Shop</h1>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline">
                <SlidersHorizontal className="mr-2 h-4 w-4" /> Filters
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <div className="mt-6">
                <FilterContent />
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {/* Desktop Sidebar */}
        <aside className="hidden md:block w-64 flex-shrink-0">
          <div className="sticky top-24">
            <h1 className="text-4xl font-display font-bold mb-8">Shop</h1>
            <FilterContent />
          </div>
        </aside>

        {/* Product Grid */}
        <main className="flex-grow">
          <div className="mb-6 flex justify-between items-center">
            <p className="text-muted-foreground">Showing {filteredProducts.length} results</p>
            {/* Sort Dropdown could go here */}
          </div>
          
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map(product => (
                <ProductCard key={product.id} {...product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-24 bg-secondary/10 rounded-lg border border-border/50">
              <Filter className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-bold font-display mb-2">No products found</h3>
              <p className="text-muted-foreground mb-4">Try adjusting your filters to see more results.</p>
              <Button onClick={() => {
                setSelectedCategory("All");
                setSelectedBrands([]);
                setPriceRange([0, 5000]);
              }}>
                Clear All Filters
              </Button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
