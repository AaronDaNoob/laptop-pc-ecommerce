import { ArrowRight, Star, Shield, Zap } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/ui/ProductCard";
import { ServiceCard } from "@/components/ui/ServiceCard";
import { products as staticProducts, services } from "@/lib/data";
import heroImage from "@assets/generated_images/futuristic_tech_store_hero_background.png";
import type { Product, ProductSpecs } from "@shared/schema";

export default function Home() {
  const { data: dbProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: async () => {
      const res = await fetch("/api/products");
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const products = dbProducts && dbProducts.length > 0 
    ? dbProducts.map(p => ({
        id: p.id,
        name: p.name,
        brand: p.brand,
        price: p.price / 100,
        category: p.category,
        image: p.image,
        condition: p.condition,
        specs: p.specs as ProductSpecs,
        inStock: p.inStock,
      }))
    : staticProducts;

  const featuredProducts = products.slice(0, 4);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent z-10" />
          <img 
            src={heroImage} 
            alt="Club Laptops Store" 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="container mx-auto px-4 relative z-20">
          <div className="max-w-2xl space-y-6">
            <div className="inline-block px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary font-mono text-sm tracking-widest uppercase">
              The Future of Computing
            </div>
            <h1 className="text-5xl md:text-7xl font-display font-bold leading-tight text-glow">
              UPGRADE YOUR <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                BATTLESTATION
              </span>
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
              Experience the pinnacle of performance with our curated selection of high-end gaming laptops and professional workstations.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <Link href="/shop">
                <Button size="lg" className="text-lg px-8 h-12">
                  Shop Now <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/services">
                <Button size="lg" variant="outline" className="text-lg px-8 h-12 bg-background/50 backdrop-blur-md">
                  Book Repair
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Banner */}
      <section className="border-y border-border/50 bg-secondary/10 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-primary/10 text-primary">
                <Shield className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-bold font-display text-lg">Official Warranty</h3>
                <p className="text-sm text-muted-foreground">Certified dealer for all major brands</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-accent/10 text-accent">
                <Zap className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-bold font-display text-lg">Expert Setup</h3>
                <p className="text-sm text-muted-foreground">Free optimization with every purchase</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-purple-500/10 text-purple-500">
                <Star className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-bold font-display text-lg">Club Rewards</h3>
                <p className="text-sm text-muted-foreground">Earn points on every purchase</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 container mx-auto px-4">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-2">New Arrivals</h2>
            <p className="text-muted-foreground">Latest tech from top manufacturers</p>
          </div>
          <Link href="/shop">
            <Button variant="ghost" className="hidden md:flex">View All <ArrowRight className="ml-2 h-4 w-4" /></Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} {...product} />
          ))}
        </div>
        
        <div className="mt-8 text-center md:hidden">
          <Link href="/shop">
            <Button variant="outline" className="w-full">View All Products</Button>
          </Link>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-secondary/5 border-t border-border/50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">Expert Services</h2>
            <p className="text-muted-foreground text-lg">
              More than just a store. We are your technical partners for repairs, upgrades, and consultations.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.slice(0, 2).map((service) => (
              <ServiceCard 
                key={service.id} 
                {...service} 
                link="/services"
                isConsultation={service.id === "consult"}
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
