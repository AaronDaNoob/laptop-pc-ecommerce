import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { CalendarIcon, Wrench, DollarSign, MessageSquare, Upload, X, Image as ImageIcon } from "lucide-react";
import { format } from "date-fns";
import { useMutation } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const repairSchema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Phone number is required"),
  deviceModel: z.string().min(2, "Device model is required"),
  issue: z.string().min(10, "Please describe the issue"),
  appointmentDate: z.date({
    required_error: "Please select a date for drop-off",
  }),
});

const sellSchema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Invalid email address"),
  deviceModel: z.string().min(2, "Device model is required"),
  specs: z.string().min(5, "Please list basic specs (CPU, RAM, Storage)"),
  condition: z.string().min(5, "Please describe the condition"),
});

export default function Services() {
  const { toast } = useToast();
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [imageError, setImageError] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const repairForm = useForm<z.infer<typeof repairSchema>>({
    resolver: zodResolver(repairSchema),
  });

  const sellForm = useForm<z.infer<typeof sellSchema>>({
    resolver: zodResolver(sellSchema),
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const maxSize = 5 * 1024 * 1024; // 5MB
    const newImages: string[] = [];

    Array.from(files).forEach(file => {
      if (file.size > maxSize) {
        toast({
          title: "File too large",
          description: `${file.name} exceeds 5MB limit`,
          variant: "destructive",
        });
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setUploadedImages(prev => [...prev, event.target!.result as string]);
          setImageError("");
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const repairMutation = useMutation({
    mutationFn: async (data: z.infer<typeof repairSchema>) => {
      const formattedData = {
        ...data,
        appointmentDate: format(data.appointmentDate, "yyyy-MM-dd"),
      };
      
      const response = await fetch("/api/repair-appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formattedData),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to book appointment");
      }

      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Appointment Confirmed!",
        description: `Your repair appointment for ${format(new Date(data.appointmentDate), "PPP")} has been scheduled. Check your email for details.`,
      });
      repairForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Booking Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const sellMutation = useMutation({
    mutationFn: async (data: z.infer<typeof sellSchema>) => {
      if (uploadedImages.length === 0) {
        throw new Error("Please upload at least one image of your laptop");
      }

      const requestData = {
        ...data,
        images: uploadedImages,
      };

      const response = await fetch("/api/sell-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestData),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to submit quote request");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Quote Request Received!",
        description: "Our team will review your device details and email you an estimate within 24 hours.",
      });
      sellForm.reset();
      setUploadedImages([]);
    },
    onError: (error: Error) => {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onRepairSubmit(data: z.infer<typeof repairSchema>) {
    repairMutation.mutate(data);
  }

  function onSellSubmit(data: z.infer<typeof sellSchema>) {
    if (uploadedImages.length === 0) {
      setImageError("Please upload at least one image of your laptop");
      return;
    }
    sellMutation.mutate(data);
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto mb-12 text-center">
        <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">Services Hub</h1>
        <p className="text-xl text-muted-foreground">
          Expert repairs, fair trade-ins, and professional consultations. All in one place.
        </p>
      </div>

      <div className="max-w-3xl mx-auto">
        <Tabs defaultValue="repair" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8 h-12">
            <TabsTrigger value="repair" className="text-base" data-testid="tab-repair">
              <Wrench className="mr-2 h-4 w-4" /> Repair
            </TabsTrigger>
            <TabsTrigger value="sell" className="text-base" data-testid="tab-sell">
              <DollarSign className="mr-2 h-4 w-4" /> Sell/Trade-in
            </TabsTrigger>
            <TabsTrigger value="consult" className="text-base" data-testid="tab-consult">
              <MessageSquare className="mr-2 h-4 w-4" /> Consultation
            </TabsTrigger>
          </TabsList>

          <TabsContent value="repair">
            <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Book a Repair Appointment</CardTitle>
                <CardDescription>
                  Schedule a time to drop off your device. Diagnostic fees are waived if you proceed with the repair.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...repairForm}>
                  <form onSubmit={repairForm.handleSubmit(onRepairSubmit)} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={repairForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name</FormLabel>
                            <FormControl>
                              <Input placeholder="John Doe" data-testid="input-repair-name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={repairForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="john@example.com" data-testid="input-repair-email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={repairForm.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="(555) 123-4567" data-testid="input-repair-phone" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={repairForm.control}
                        name="deviceModel"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Device Model</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. MacBook Pro 2021" data-testid="input-repair-device" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={repairForm.control}
                      name="appointmentDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Preferred Drop-off Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={`w-full pl-3 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                                  data-testid="button-repair-date"
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                disabled={(date) =>
                                  date < new Date() || date < new Date("1900-01-01")
                                }
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={repairForm.control}
                      name="issue"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Issue Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us what's wrong with your device..." 
                              className="resize-none min-h-[100px]"
                              data-testid="textarea-repair-issue"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full" 
                      size="lg"
                      disabled={repairMutation.isPending}
                      data-testid="button-submit-repair"
                    >
                      {repairMutation.isPending ? "Booking..." : "Confirm Booking"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sell">
            <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Get an Instant Quote</CardTitle>
                <CardDescription>
                  Fill out the details below to receive an estimated trade-in value for your laptop. At least one photo is required.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...sellForm}>
                  <form onSubmit={sellForm.handleSubmit(onSellSubmit)} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={sellForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Jane Smith" data-testid="input-sell-name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={sellForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="jane@example.com" data-testid="input-sell-email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={sellForm.control}
                      name="deviceModel"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Device Model</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Dell XPS 15 9520" data-testid="input-sell-device" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={sellForm.control}
                      name="specs"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Specs</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. i7, 16GB RAM, 512GB SSD, RTX 3050" data-testid="input-sell-specs" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={sellForm.control}
                      name="condition"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Condition</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe any scratches, dents, or functional issues..." 
                              className="resize-none"
                              data-testid="textarea-sell-condition"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Image Upload */}
                    <div className="space-y-2">
                      <Label className="flex items-center gap-1">
                        Device Photos <span className="text-destructive">*</span>
                      </Label>
                      <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors">
                        <input
                          type="file"
                          ref={fileInputRef}
                          onChange={handleImageUpload}
                          accept="image/*"
                          multiple
                          className="hidden"
                          data-testid="input-sell-images"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => fileInputRef.current?.click()}
                          className="mb-2"
                          data-testid="button-upload-images"
                        >
                          <Upload className="mr-2 h-4 w-4" /> Upload Photos
                        </Button>
                        <p className="text-sm text-muted-foreground">
                          Upload at least 1 photo of your laptop (max 5MB each)
                        </p>
                      </div>
                      
                      {uploadedImages.length > 0 && (
                        <div className="grid grid-cols-3 gap-4 mt-4">
                          {uploadedImages.map((img, index) => (
                            <div key={index} className="relative group">
                              <img
                                src={img}
                                alt={`Upload ${index + 1}`}
                                className="w-full h-24 object-cover rounded-lg border border-border"
                              />
                              <Button
                                type="button"
                                variant="destructive"
                                size="icon"
                                className="absolute -top-2 -right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                                onClick={() => removeImage(index)}
                                data-testid={`button-remove-image-${index}`}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {imageError && (
                        <p className="text-sm text-destructive flex items-center gap-1">
                          <ImageIcon className="h-4 w-4" /> {imageError}
                        </p>
                      )}
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full" 
                      size="lg"
                      disabled={sellMutation.isPending}
                      data-testid="button-submit-sell"
                    >
                      {sellMutation.isPending ? "Submitting..." : "Request Quote"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="consult">
            <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Talk to an Expert</CardTitle>
                <CardDescription>
                  Not sure what you need? Our experts can help you build the perfect setup or choose the right laptop for your workflow.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <div className="bg-primary/10 p-4 rounded-full mb-6">
                  <MessageSquare className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">Free 15-Minute Consultation</h3>
                <p className="text-muted-foreground max-w-md mb-8">
                  Available Monday-Friday, 10am - 6pm. Walk-ins welcome, or call us to reserve a specific slot.
                </p>
                <div className="flex gap-4">
                  <Button size="lg" variant="default" data-testid="button-call">Call (555) 123-4567</Button>
                  <Button size="lg" variant="outline" data-testid="button-chat">Chat Online</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
