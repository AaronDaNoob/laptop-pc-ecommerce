import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, ShoppingCart, Check, Cpu, CircuitBoard, HardDrive, Monitor, Database, Layers, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { products as staticProducts } from "@/lib/data";
import { useCart } from "@/lib/cart";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import type { Product, ProductSpecs } from "@shared/schema";

const conditionColors: Record<string, string> = {
  "New": "bg-green-500/20 text-green-400 border-green-500/30",
  "Refurbished": "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  "Used": "bg-orange-500/20 text-orange-400 border-orange-500/30",
};

export default function ProductPage() {
  const [, params] = useRoute("/product/:id");
  const productId = params?.id ? parseInt(params.id) : null;
  
  const { addItem } = useCart();
  const { toast } = useToast();
  const [added, setAdded] = useState(false);

  const { data: dbProduct, isLoading } = useQuery<Product>({
    queryKey: ["/api/products", productId],
    queryFn: async () => {
      const res = await fetch(`/api/products/${productId}`);
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: !!productId,
  });

  const staticProduct = staticProducts.find(p => p.id === productId);
  
  const product = dbProduct 
    ? {
        id: dbProduct.id,
        name: dbProduct.name,
        brand: dbProduct.brand,
        price: dbProduct.price / 100,
        category: dbProduct.category,
        image: dbProduct.image,
        condition: dbProduct.condition,
        specs: dbProduct.specs as ProductSpecs,
        inStock: dbProduct.inStock,
      }
    : staticProduct;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
          <Link href="/shop">
            <Button variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Shop
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addItem({ id: product.id, name: product.name, brand: product.brand, price: product.price, image: product.image });
    setAdded(true);
    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart.`,
    });
    setTimeout(() => setAdded(false), 2000);
  };

  const specs = [
    { icon: Cpu, label: "Processor", value: product.specs.cpu },
    { icon: CircuitBoard, label: "Graphics", value: product.specs.gpu },
    { icon: HardDrive, label: "Memory", value: product.specs.ram },
    { icon: Database, label: "Storage", value: product.specs.storage },
    { icon: Monitor, label: "Display", value: product.specs.screen },
    { icon: Layers, label: "Operating System", value: product.specs.os },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        <Link href="/shop">
          <Button variant="ghost" className="mb-8" data-testid="button-back-shop">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Shop
          </Button>
        </Link>

        <div className="grid lg:grid-cols-2 gap-12">
          <div className="relative">
            <Card className="overflow-hidden border-border/50 bg-card/50 backdrop-blur-sm">
              <div className="relative aspect-square bg-secondary/20 p-8 flex items-center justify-center">
                <Badge 
                  className={`absolute top-4 left-4 z-10 border text-sm ${conditionColors[product.condition] || conditionColors["New"]}`}
                  data-testid="badge-product-condition"
                >
                  {product.condition}
                </Badge>
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-contain drop-shadow-2xl"
                  data-testid="img-product"
                />
                {!product.inStock && (
                  <div className="absolute inset-0 bg-background/60 backdrop-blur-[2px] flex items-center justify-center">
                    <Badge variant="destructive" className="text-lg px-4 py-2">Out of Stock</Badge>
                  </div>
                )}
              </div>
            </Card>
          </div>

          <div className="space-y-6">
            <div>
              <p className="text-sm font-mono text-primary/80 uppercase tracking-wider mb-2" data-testid="text-brand">
                {product.brand}
              </p>
              <h1 className="text-4xl md:text-5xl font-display font-bold mb-4" data-testid="text-product-name">
                {product.name}
              </h1>
              <div className="flex items-center gap-4">
                <span className="text-3xl font-display font-bold text-accent" data-testid="text-price">
                  ${product.price.toLocaleString()}
                </span>
                <Badge variant={product.inStock ? "secondary" : "destructive"} data-testid="badge-stock-status">
                  {product.inStock ? "In Stock" : "Out of Stock"}
                </Badge>
              </div>
            </div>

            <Separator />

            <div>
              <h2 className="text-xl font-display font-semibold mb-4">Specifications</h2>
              <div className="grid gap-3">
                {specs.map((spec, index) => (
                  <Card key={index} className="border-border/50 bg-secondary/20">
                    <CardContent className="p-4 flex items-center gap-4">
                      <div className="bg-primary/10 p-2 rounded-lg">
                        <spec.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">{spec.label}</p>
                        <p className="font-medium" data-testid={`text-spec-${spec.label.toLowerCase().replace(' ', '-')}`}>
                          {spec.value}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <Separator />

            <div className="flex gap-4">
              <Button 
                size="lg"
                className="flex-1 h-14 text-lg font-medium" 
                variant={added ? "secondary" : product.inStock ? "default" : "secondary"}
                disabled={!product.inStock}
                onClick={handleAddToCart}
                data-testid="button-add-to-cart"
              >
                {added ? (
                  <>
                    <Check className="w-5 h-5 mr-2" />
                    Added to Cart!
                  </>
                ) : product.inStock ? (
                  <>
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    Add to Cart
                  </>
                ) : (
                  "Notify Me When Available"
                )}
              </Button>
            </div>

            <Card className="border-border/50 bg-secondary/10">
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">
                  Need help choosing? Our tech experts are available for free consultations. 
                  Visit our <Link href="/services" className="text-primary hover:underline">Services</Link> page to book a session.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
