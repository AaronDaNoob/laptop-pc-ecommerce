import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { RefreshCw, Wrench, DollarSign, Users, Calendar, Mail, Phone, Laptop, ShoppingBag, Image as ImageIcon, Package, Plus, Trash2, Edit, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import type { RepairAppointment, SellRequest, Order, Product, ProductSpecs } from "@shared/schema";

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
    pending: "secondary",
    confirmed: "default",
    completed: "outline",
    cancelled: "destructive",
  };
  
  return (
    <Badge variant={variants[status] || "secondary"} className="capitalize">
      {status}
    </Badge>
  );
}

interface OrderItem {
  id: number;
  name: string;
  brand: string;
  price: number;
  quantity: number;
}

const emptyProduct = {
  name: "",
  brand: "",
  price: 0,
  category: "Gaming",
  image: "",
  condition: "New",
  specs: { cpu: "", gpu: "", ram: "", storage: "", os: "", screen: "" },
  inStock: true,
};

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showEditProduct, setShowEditProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<{ id: number } & typeof emptyProduct | null>(null);
  const [newProduct, setNewProduct] = useState(emptyProduct);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: repairAppointments, isLoading: loadingRepairs, refetch: refetchRepairs } = useQuery<RepairAppointment[]>({
    queryKey: ["/api/repair-appointments"],
    queryFn: async () => {
      const res = await fetch("/api/repair-appointments");
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: isAuthenticated,
  });

  const { data: sellRequests, isLoading: loadingSells, refetch: refetchSells } = useQuery<SellRequest[]>({
    queryKey: ["/api/sell-requests"],
    queryFn: async () => {
      const res = await fetch("/api/sell-requests");
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: isAuthenticated,
  });

  const { data: orders, isLoading: loadingOrders, refetch: refetchOrders } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
    queryFn: async () => {
      const res = await fetch("/api/orders");
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: isAuthenticated,
  });

  const { data: products, isLoading: loadingProducts, refetch: refetchProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: async () => {
      const res = await fetch("/api/products");
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: isAuthenticated,
  });

  const createProductMutation = useMutation({
    mutationFn: async (product: typeof emptyProduct) => {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...product, price: Math.round(product.price * 100) }),
      });
      if (!res.ok) throw new Error("Failed to create product");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setShowAddProduct(false);
      setNewProduct(emptyProduct);
      toast({ title: "Product Added", description: "The listing has been added successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add product.", variant: "destructive" });
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete product");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({ title: "Product Removed", description: "The listing has been removed." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to remove product.", variant: "destructive" });
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async (product: { id: number } & typeof emptyProduct) => {
      const res = await fetch(`/api/products/${product.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...product, price: Math.round(product.price * 100) }),
      });
      if (!res.ok) throw new Error("Failed to update product");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setShowEditProduct(false);
      setEditingProduct(null);
      toast({ title: "Product Updated", description: "The listing has been updated successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update product.", variant: "destructive" });
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "admin123") {
      setIsAuthenticated(true);
      setError("");
    } else {
      setError("Invalid password");
    }
  };

  const handleRefresh = () => {
    refetchRepairs();
    refetchSells();
    refetchOrders();
    refetchProducts();
  };

  const handleAddProduct = () => {
    if (!newProduct.name || !newProduct.brand || !newProduct.price) {
      toast({ title: "Missing Fields", description: "Please fill in name, brand, and price.", variant: "destructive" });
      return;
    }
    createProductMutation.mutate(newProduct);
  };

  const handleEditProduct = (product: Product) => {
    const specs = product.specs as ProductSpecs;
    setEditingProduct({
      id: product.id,
      name: product.name,
      brand: product.brand,
      price: product.price / 100,
      category: product.category,
      image: product.image,
      condition: product.condition,
      specs: specs,
      inStock: product.inStock,
    });
    setShowEditProduct(true);
  };

  const handleUpdateProduct = () => {
    if (!editingProduct || !editingProduct.name || !editingProduct.brand || !editingProduct.price) {
      toast({ title: "Missing Fields", description: "Please fill in name, brand, and price.", variant: "destructive" });
      return;
    }
    updateProductMutation.mutate(editingProduct);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center">
        <Card className="w-full max-w-md border-border/50 bg-card/50 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-display">Vendor Dashboard</CardTitle>
            <CardDescription>Enter the admin password to access customer data</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                data-testid="input-admin-password"
              />
              {error && <p className="text-destructive text-sm">{error}</p>}
              <Button type="submit" className="w-full" data-testid="button-admin-login">
                Access Dashboard
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                Default password: admin123
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalRepairs = repairAppointments?.length || 0;
  const totalSells = sellRequests?.length || 0;
  const totalOrders = orders?.length || 0;
  const totalProducts = products?.length || 0;
  const pendingRepairs = repairAppointments?.filter(r => r.status === "pending").length || 0;
  const totalRevenue = orders?.reduce((sum, order) => sum + (order.totalAmount / 100), 0) || 0;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold">Vendor Dashboard</h1>
          <p className="text-muted-foreground">Manage customer appointments, requests, and orders</p>
        </div>
        <Button 
          variant="outline" 
          onClick={handleRefresh}
          data-testid="button-refresh-data"
        >
          <RefreshCw className="mr-2 h-4 w-4" /> Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
        <Card className="border-border/50 bg-card/50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-primary/10 text-primary">
                <Wrench className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalRepairs}</p>
                <p className="text-sm text-muted-foreground">Repairs</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-border/50 bg-card/50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-accent/10 text-accent">
                <DollarSign className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalSells}</p>
                <p className="text-sm text-muted-foreground">Sell Requests</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-blue-500/10 text-blue-500">
                <ShoppingBag className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalOrders}</p>
                <p className="text-sm text-muted-foreground">Orders</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-yellow-500/10 text-yellow-500">
                <Calendar className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{pendingRepairs}</p>
                <p className="text-sm text-muted-foreground">Pending</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-full bg-green-500/10 text-green-500">
                <Package className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">${totalRevenue.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Revenue</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="listings" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="listings" data-testid="tab-admin-listings">
            <Laptop className="mr-2 h-4 w-4" /> Listings ({totalProducts})
          </TabsTrigger>
          <TabsTrigger value="orders" data-testid="tab-admin-orders">
            <ShoppingBag className="mr-2 h-4 w-4" /> Orders ({totalOrders})
          </TabsTrigger>
          <TabsTrigger value="repairs" data-testid="tab-admin-repairs">
            <Wrench className="mr-2 h-4 w-4" /> Repairs ({totalRepairs})
          </TabsTrigger>
          <TabsTrigger value="sells" data-testid="tab-admin-sells">
            <DollarSign className="mr-2 h-4 w-4" /> Sell Requests ({totalSells})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="listings">
          <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Product Listings</CardTitle>
                <CardDescription>Manage your laptop inventory</CardDescription>
              </div>
              <Dialog open={showAddProduct} onOpenChange={setShowAddProduct}>
                <DialogTrigger asChild>
                  <Button data-testid="button-add-product">
                    <Plus className="mr-2 h-4 w-4" /> Add Listing
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Product</DialogTitle>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Product Name</Label>
                        <Input
                          id="name"
                          value={newProduct.name}
                          onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                          placeholder="e.g., MacBook Pro 16"
                          data-testid="input-product-name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="brand">Brand</Label>
                        <Input
                          id="brand"
                          value={newProduct.brand}
                          onChange={(e) => setNewProduct({ ...newProduct, brand: e.target.value })}
                          placeholder="e.g., Apple"
                          data-testid="input-product-brand"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="price">Price ($)</Label>
                        <Input
                          id="price"
                          type="number"
                          value={newProduct.price || ""}
                          onChange={(e) => setNewProduct({ ...newProduct, price: parseFloat(e.target.value) || 0 })}
                          placeholder="1999.99"
                          data-testid="input-product-price"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="category">Category</Label>
                        <Select value={newProduct.category} onValueChange={(v) => setNewProduct({ ...newProduct, category: v })}>
                          <SelectTrigger data-testid="select-product-category">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Gaming">Gaming</SelectItem>
                            <SelectItem value="Workstation">Workstation</SelectItem>
                            <SelectItem value="Business">Business</SelectItem>
                            <SelectItem value="Creative">Creative</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="condition">Condition</Label>
                        <Select value={newProduct.condition} onValueChange={(v) => setNewProduct({ ...newProduct, condition: v })}>
                          <SelectTrigger data-testid="select-product-condition">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="New">New</SelectItem>
                            <SelectItem value="Refurbished">Refurbished</SelectItem>
                            <SelectItem value="Used">Used</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="image">Image URL</Label>
                      <Input
                        id="image"
                        value={newProduct.image}
                        onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })}
                        placeholder="https://example.com/image.jpg"
                        data-testid="input-product-image"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="font-semibold">Specifications</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          placeholder="CPU (e.g., i9-13900H)"
                          value={newProduct.specs.cpu}
                          onChange={(e) => setNewProduct({ ...newProduct, specs: { ...newProduct.specs, cpu: e.target.value } })}
                          data-testid="input-spec-cpu"
                        />
                        <Input
                          placeholder="GPU (e.g., RTX 4090)"
                          value={newProduct.specs.gpu}
                          onChange={(e) => setNewProduct({ ...newProduct, specs: { ...newProduct.specs, gpu: e.target.value } })}
                          data-testid="input-spec-gpu"
                        />
                        <Input
                          placeholder="RAM (e.g., 32GB DDR5)"
                          value={newProduct.specs.ram}
                          onChange={(e) => setNewProduct({ ...newProduct, specs: { ...newProduct.specs, ram: e.target.value } })}
                          data-testid="input-spec-ram"
                        />
                        <Input
                          placeholder="Storage (e.g., 1TB SSD)"
                          value={newProduct.specs.storage}
                          onChange={(e) => setNewProduct({ ...newProduct, specs: { ...newProduct.specs, storage: e.target.value } })}
                          data-testid="input-spec-storage"
                        />
                        <Input
                          placeholder="OS (e.g., Windows 11)"
                          value={newProduct.specs.os}
                          onChange={(e) => setNewProduct({ ...newProduct, specs: { ...newProduct.specs, os: e.target.value } })}
                          data-testid="input-spec-os"
                        />
                        <Input
                          placeholder="Screen (e.g., 16&quot; 4K OLED)"
                          value={newProduct.specs.screen}
                          onChange={(e) => setNewProduct({ ...newProduct, specs: { ...newProduct.specs, screen: e.target.value } })}
                          data-testid="input-spec-screen"
                        />
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="inStock"
                        checked={newProduct.inStock}
                        onCheckedChange={(checked) => setNewProduct({ ...newProduct, inStock: checked })}
                        data-testid="switch-in-stock"
                      />
                      <Label htmlFor="inStock">In Stock</Label>
                    </div>
                  </div>
                  <DialogFooter>
                    <DialogClose asChild>
                      <Button variant="outline">Cancel</Button>
                    </DialogClose>
                    <Button onClick={handleAddProduct} disabled={createProductMutation.isPending} data-testid="button-submit-product">
                      {createProductMutation.isPending ? "Adding..." : "Add Product"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {loadingProducts ? (
                <div className="text-center py-8 text-muted-foreground">Loading...</div>
              ) : !products?.length ? (
                <div className="text-center py-12">
                  <Laptop className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No products yet. Add your first listing!</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Brand</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Condition</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Stock</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {products.map((product) => {
                        const specs = product.specs as ProductSpecs;
                        return (
                          <TableRow key={product.id} data-testid={`row-product-${product.id}`}>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                {product.image && (
                                  <img src={product.image} alt={product.name} className="w-12 h-12 object-contain rounded" />
                                )}
                                <div>
                                  <p className="font-medium">{product.name}</p>
                                  <p className="text-xs text-muted-foreground">{specs?.cpu} | {specs?.ram}</p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>{product.brand}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{product.category}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge 
                                className={
                                  product.condition === "New" ? "bg-green-500/20 text-green-400" :
                                  product.condition === "Refurbished" ? "bg-yellow-500/20 text-yellow-400" :
                                  "bg-orange-500/20 text-orange-400"
                                }
                              >
                                {product.condition}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-bold text-accent">
                              ${(product.price / 100).toLocaleString()}
                            </TableCell>
                            <TableCell>
                              <Badge variant={product.inStock ? "default" : "destructive"}>
                                {product.inStock ? "In Stock" : "Out of Stock"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleEditProduct(product)}
                                  data-testid={`button-edit-product-${product.id}`}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => deleteProductMutation.mutate(product.id)}
                                  disabled={deleteProductMutation.isPending}
                                  data-testid={`button-delete-product-${product.id}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          <Dialog open={showEditProduct} onOpenChange={setShowEditProduct}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Edit Product</DialogTitle>
              </DialogHeader>
              {editingProduct && (
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-name">Product Name</Label>
                      <Input
                        id="edit-name"
                        value={editingProduct.name}
                        onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                        placeholder="e.g., MacBook Pro 16"
                        data-testid="input-edit-product-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-brand">Brand</Label>
                      <Input
                        id="edit-brand"
                        value={editingProduct.brand}
                        onChange={(e) => setEditingProduct({ ...editingProduct, brand: e.target.value })}
                        placeholder="e.g., Apple"
                        data-testid="input-edit-product-brand"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-price">Price ($)</Label>
                      <Input
                        id="edit-price"
                        type="number"
                        value={editingProduct.price || ""}
                        onChange={(e) => setEditingProduct({ ...editingProduct, price: parseFloat(e.target.value) || 0 })}
                        placeholder="1999.99"
                        data-testid="input-edit-product-price"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-category">Category</Label>
                      <Select value={editingProduct.category} onValueChange={(v) => setEditingProduct({ ...editingProduct, category: v })}>
                        <SelectTrigger data-testid="select-edit-product-category">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Gaming">Gaming</SelectItem>
                          <SelectItem value="Workstation">Workstation</SelectItem>
                          <SelectItem value="Business">Business</SelectItem>
                          <SelectItem value="Creative">Creative</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-condition">Condition</Label>
                      <Select value={editingProduct.condition} onValueChange={(v) => setEditingProduct({ ...editingProduct, condition: v })}>
                        <SelectTrigger data-testid="select-edit-product-condition">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="New">New</SelectItem>
                          <SelectItem value="Refurbished">Refurbished</SelectItem>
                          <SelectItem value="Used">Used</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-image">Image URL</Label>
                    <Input
                      id="edit-image"
                      value={editingProduct.image}
                      onChange={(e) => setEditingProduct({ ...editingProduct, image: e.target.value })}
                      placeholder="https://example.com/image.jpg"
                      data-testid="input-edit-product-image"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="font-semibold">Specifications</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        placeholder="CPU (e.g., i9-13900H)"
                        value={editingProduct.specs.cpu}
                        onChange={(e) => setEditingProduct({ ...editingProduct, specs: { ...editingProduct.specs, cpu: e.target.value } })}
                        data-testid="input-edit-spec-cpu"
                      />
                      <Input
                        placeholder="GPU (e.g., RTX 4090)"
                        value={editingProduct.specs.gpu}
                        onChange={(e) => setEditingProduct({ ...editingProduct, specs: { ...editingProduct.specs, gpu: e.target.value } })}
                        data-testid="input-edit-spec-gpu"
                      />
                      <Input
                        placeholder="RAM (e.g., 32GB DDR5)"
                        value={editingProduct.specs.ram}
                        onChange={(e) => setEditingProduct({ ...editingProduct, specs: { ...editingProduct.specs, ram: e.target.value } })}
                        data-testid="input-edit-spec-ram"
                      />
                      <Input
                        placeholder="Storage (e.g., 1TB SSD)"
                        value={editingProduct.specs.storage}
                        onChange={(e) => setEditingProduct({ ...editingProduct, specs: { ...editingProduct.specs, storage: e.target.value } })}
                        data-testid="input-edit-spec-storage"
                      />
                      <Input
                        placeholder="OS (e.g., Windows 11)"
                        value={editingProduct.specs.os}
                        onChange={(e) => setEditingProduct({ ...editingProduct, specs: { ...editingProduct.specs, os: e.target.value } })}
                        data-testid="input-edit-spec-os"
                      />
                      <Input
                        placeholder="Screen (e.g., 16&quot; 4K OLED)"
                        value={editingProduct.specs.screen}
                        onChange={(e) => setEditingProduct({ ...editingProduct, specs: { ...editingProduct.specs, screen: e.target.value } })}
                        data-testid="input-edit-spec-screen"
                      />
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="edit-inStock"
                      checked={editingProduct.inStock}
                      onCheckedChange={(checked) => setEditingProduct({ ...editingProduct, inStock: checked })}
                      data-testid="switch-edit-in-stock"
                    />
                    <Label htmlFor="edit-inStock">In Stock</Label>
                  </div>
                </div>
              )}
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancel</Button>
                </DialogClose>
                <Button onClick={handleUpdateProduct} disabled={updateProductMutation.isPending} data-testid="button-update-product">
                  {updateProductMutation.isPending ? "Updating..." : "Update Product"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="orders">
          <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Buy Orders</CardTitle>
              <CardDescription>All customer purchase orders</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingOrders ? (
                <div className="text-center py-8 text-muted-foreground">Loading...</div>
              ) : !orders?.length ? (
                <div className="text-center py-12">
                  <ShoppingBag className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No orders yet</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Customer</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Items</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.map((order) => {
                        const items = order.items as OrderItem[];
                        return (
                          <TableRow key={order.id} data-testid={`row-order-${order.id}`}>
                            <TableCell className="font-medium">{order.customerName}</TableCell>
                            <TableCell>
                              <div className="flex flex-col gap-1 text-sm">
                                <span className="flex items-center gap-1">
                                  <Mail className="h-3 w-3" /> {order.customerEmail}
                                </span>
                                <span className="flex items-center gap-1 text-muted-foreground">
                                  <Phone className="h-3 w-3" /> {order.customerPhone}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="text-sm">
                                {items.map((item, idx) => (
                                  <div key={idx} className="flex items-center gap-1">
                                    <Laptop className="h-3 w-3 text-primary" />
                                    {item.name} x{item.quantity}
                                  </div>
                                ))}
                              </div>
                            </TableCell>
                            <TableCell className="font-bold text-accent">
                              ${(order.totalAmount / 100).toLocaleString()}
                            </TableCell>
                            <TableCell>
                              {format(new Date(order.createdAt), "MMM d, yyyy")}
                            </TableCell>
                            <TableCell>
                              <StatusBadge status={order.status} />
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="repairs">
          <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Repair Appointments</CardTitle>
              <CardDescription>All customer repair booking requests</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingRepairs ? (
                <div className="text-center py-8 text-muted-foreground">Loading...</div>
              ) : !repairAppointments?.length ? (
                <div className="text-center py-12">
                  <Wrench className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No repair appointments yet</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Customer</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Device</TableHead>
                        <TableHead>Issue</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {repairAppointments.map((appointment) => (
                        <TableRow key={appointment.id} data-testid={`row-repair-${appointment.id}`}>
                          <TableCell className="font-medium">{appointment.name}</TableCell>
                          <TableCell>
                            <div className="flex flex-col gap-1 text-sm">
                              <span className="flex items-center gap-1">
                                <Mail className="h-3 w-3" /> {appointment.email}
                              </span>
                              <span className="flex items-center gap-1 text-muted-foreground">
                                <Phone className="h-3 w-3" /> {appointment.phone}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className="flex items-center gap-1">
                              <Laptop className="h-3 w-3 text-primary" />
                              {appointment.deviceModel}
                            </span>
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate">{appointment.issue}</TableCell>
                          <TableCell>
                            {format(new Date(appointment.appointmentDate), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell>
                            <StatusBadge status={appointment.status} />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sells">
          <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Sell / Trade-in Requests</CardTitle>
              <CardDescription>All customer device valuation requests (with photos)</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingSells ? (
                <div className="text-center py-8 text-muted-foreground">Loading...</div>
              ) : !sellRequests?.length ? (
                <div className="text-center py-12">
                  <DollarSign className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No sell requests yet</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Customer</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Device</TableHead>
                        <TableHead>Specs</TableHead>
                        <TableHead>Condition</TableHead>
                        <TableHead>Photos</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sellRequests.map((request) => (
                        <TableRow key={request.id} data-testid={`row-sell-${request.id}`}>
                          <TableCell className="font-medium">{request.name}</TableCell>
                          <TableCell>
                            <span className="flex items-center gap-1 text-sm">
                              <Mail className="h-3 w-3" /> {request.email}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span className="flex items-center gap-1">
                              <Laptop className="h-3 w-3 text-primary" />
                              {request.deviceModel}
                            </span>
                          </TableCell>
                          <TableCell className="max-w-[150px] truncate text-sm">{request.specs}</TableCell>
                          <TableCell className="max-w-[150px] truncate text-sm">{request.condition}</TableCell>
                          <TableCell>
                            {request.images && request.images.length > 0 ? (
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm" data-testid={`button-view-images-${request.id}`}>
                                    <ImageIcon className="h-3 w-3 mr-1" /> {request.images.length} photos
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="max-w-2xl">
                                  <DialogHeader>
                                    <DialogTitle>Device Photos - {request.deviceModel}</DialogTitle>
                                  </DialogHeader>
                                  <div className="grid grid-cols-2 gap-4 mt-4">
                                    {request.images.map((img, idx) => (
                                      <img
                                        key={idx}
                                        src={img}
                                        alt={`Device photo ${idx + 1}`}
                                        className="w-full h-48 object-cover rounded-lg border border-border"
                                      />
                                    ))}
                                  </div>
                                </DialogContent>
                              </Dialog>
                            ) : (
                              <span className="text-muted-foreground text-sm">No photos</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <StatusBadge status={request.status} />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
