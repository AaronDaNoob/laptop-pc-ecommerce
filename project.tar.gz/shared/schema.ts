import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, date, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/auth";

export const products = pgTable("products", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  name: text("name").notNull(),
  brand: text("brand").notNull(),
  price: integer("price").notNull(),
  category: text("category").notNull(),
  image: text("image").notNull(),
  condition: text("condition").notNull().default("New"),
  specs: jsonb("specs").notNull(),
  inStock: boolean("in_stock").notNull().default(true),
});

export const repairAppointments = pgTable("repair_appointments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  deviceModel: text("device_model").notNull(),
  issue: text("issue").notNull(),
  appointmentDate: date("appointment_date").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sellRequests = pgTable("sell_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  deviceModel: text("device_model").notNull(),
  specs: text("specs").notNull(),
  condition: text("condition").notNull(),
  images: text("images").array().notNull(),
  status: text("status").notNull().default("pending"),
  estimatedValue: integer("estimated_value"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone").notNull(),
  shippingAddress: text("shipping_address").notNull(),
  items: jsonb("items").notNull(),
  totalAmount: integer("total_amount").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const productSpecsSchema = z.object({
  cpu: z.string(),
  gpu: z.string(),
  ram: z.string(),
  storage: z.string(),
  os: z.string(),
  screen: z.string(),
});

export const insertProductSchema = createInsertSchema(products, {
  specs: productSpecsSchema,
  inStock: z.boolean().optional(),
});

export const insertRepairAppointmentSchema = createInsertSchema(repairAppointments).omit({
  id: true,
  status: true,
  createdAt: true,
});

export const insertSellRequestSchema = createInsertSchema(sellRequests).omit({
  id: true,
  status: true,
  estimatedValue: true,
  createdAt: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  status: true,
  createdAt: true,
});

export type ProductSpecs = z.infer<typeof productSpecsSchema>;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export type InsertRepairAppointment = z.infer<typeof insertRepairAppointmentSchema>;
export type RepairAppointment = typeof repairAppointments.$inferSelect;

export type InsertSellRequest = z.infer<typeof insertSellRequestSchema>;
export type SellRequest = typeof sellRequests.$inferSelect;

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;
